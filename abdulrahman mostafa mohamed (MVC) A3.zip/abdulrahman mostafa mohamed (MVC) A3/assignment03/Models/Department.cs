﻿namespace assignment02.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string mgrname { get; set; }

        public List<student> students { get; set; }
        public List<course> courses { get; set; }
        public List<teacher> teachrs { get; set; }

    }
}
